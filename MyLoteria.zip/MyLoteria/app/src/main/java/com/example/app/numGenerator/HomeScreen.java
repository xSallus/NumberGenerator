package com.example.app.numGenerator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class HomeScreen extends AppCompatActivity {

    TextView outPuts;
    EditText range;
    EditText howmany;
    Jogo jog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_screen);

        outPuts = findViewById(R.id.output_field);
        range = findViewById(R.id.range);
        howmany = findViewById(R.id.how_many);

    }

    public String setArray() {
        jog = new Jogo(Integer.parseInt(howmany.getText().toString()), Integer.parseInt(range.getText().toString()));
        return jog.toString();
    }

    public void OnClick(View v) {
        outPuts.setText(setArray());
        range.setText(null);
        howmany.setText(null);
    }
}