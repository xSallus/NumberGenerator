package com.example.app.numGenerator;

import androidx.annotation.NonNull;

import java.util.Arrays;
import java.util.Random;

public class Jogo
{
    private Integer x;
    private Integer[] jogo;
    private Random rn = new Random();

    public Jogo() {

    }

    public Jogo(int x, int seed) {
        this.setX(x);
        this.jogo = new Integer[this.getX()];
        for(int i=0;i<x;i++) {
            jogo[i] = rn.nextInt(seed);
        }
    }

    private void setX(Integer x) {
        this.x = x;
    }

    private Integer getX() {
        return x;
    }

    private void setJogo(Integer[] jogo) {
        this.jogo = jogo;
    }

    public Integer[] getJogo() {
        return jogo;
    }

    @Override @NonNull
    public String toString() {
        return Arrays.toString(jogo);
    }
}